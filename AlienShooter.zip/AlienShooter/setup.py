
# THIS SCRIPT SHOULD BE CALLED SETUP.PY
import cx_Freeze 

executables = [
        #                   name of your game script
        cx_Freeze.Executable("AlienShooter.py") 
] 
cx_Freeze.setup( 
        name = "Alien Shooter", 
        options = {"build_exe": {"packages":["pygame"]}},
        description = "Alien Shooter Game", 
        executables = executables)








